function validate(){
	 var regexForQuestions="^[a-zA-Z]+$";
	
	 
	 var Q1=document.getElementById("Q1").value;
     var Q2=document.getElementById("Q2").value;
     var Q3=document.getElementById("Q3").value;
     var i=0;
    
	 if(Q1=""||!(Q1.match(regexForQuestions))||!(Q1.length<=20)){
         document.getElementById("q1").innerHTML="Enter a valid answer";
         i+=1;
     }else{
         document.getElementById("q1").innerHTML="";
       
     }
      if(Q2=""||!(Q2.match(regexForQuestions))||!(Q2.length<=20)){
         document.getElementById("q2").innerHTML="Enter a valid answer";
         i+=1;
        
     }else{
         document.getElementById("q2").innerHTML="";
       
     }
      if(Q3=""||!(Q3.match(regexForQuestions))||!(Q3.length<=20)){
         document.getElementById("q3").innerHTML="Enter a valid answer";
         i+=1;
		}else{
         document.getElementById("q3").innerHTML="";
         }
      if(i==0){
    	  return true;
      }
      return false;
     
}