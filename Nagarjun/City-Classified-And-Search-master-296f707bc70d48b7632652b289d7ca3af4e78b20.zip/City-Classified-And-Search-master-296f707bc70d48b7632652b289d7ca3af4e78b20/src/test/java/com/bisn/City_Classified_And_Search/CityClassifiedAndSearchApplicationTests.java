package com.bisn.City_Classified_And_Search;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityClassifiedAndSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
