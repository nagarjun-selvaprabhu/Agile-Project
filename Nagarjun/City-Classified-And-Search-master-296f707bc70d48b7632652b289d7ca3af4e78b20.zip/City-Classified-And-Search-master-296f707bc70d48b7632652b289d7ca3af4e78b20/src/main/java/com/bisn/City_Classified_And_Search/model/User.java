package com.bisn.City_Classified_And_Search.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bisn.City_Classified_And_Search.Annotations.FirstName;
import com.bisn.City_Classified_And_Search.Annotations.LastName;

public class User {

	public User() {
	}

	@NotNull(message = "Id cannot be empty")
	private int id;

	private boolean role;
	@FirstName
	@NotEmpty(message = "firstName cannot be empty")
	private String firstName;

	@NotEmpty(message = "lastName cannot be empty")
	@LastName
	private String lastName;

	@Email(message = "email should be valid")
	@NotEmpty(message = "email should be valid")
	private String email;

	@NotEmpty(message = "password cannot be empty")
	private String password;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isRole() {
		return role;
	}

	public void setRole(boolean role) {
		this.role = role;
	}

	public User(int id, String firstName, String lastName, String email, boolean role, String password) {
		super();
		this.id = id;

		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.role = role;
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", password=" + password + "]" + "role=" + role;
	}
}
