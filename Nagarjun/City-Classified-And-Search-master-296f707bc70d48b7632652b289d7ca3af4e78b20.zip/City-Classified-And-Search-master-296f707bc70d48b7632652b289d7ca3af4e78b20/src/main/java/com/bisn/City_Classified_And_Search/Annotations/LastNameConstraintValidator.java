package com.bisn.City_Classified_And_Search.Annotations;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class LastNameConstraintValidator implements ConstraintValidator<LastName, String> {

	public boolean isValid(String s, ConstraintValidatorContext cvc) {

		return !(s.matches("^\\d"));
	}
}