package com.bisn.City_Classified_And_Search.service;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bisn.City_Classified_And_Search.model.Advertisement;
import com.bisn.City_Classified_And_Search.model.Feedback;
import com.bisn.City_Classified_And_Search.model.Login;
import com.bisn.City_Classified_And_Search.model.User;

@Service
public class UserService {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public int updateuser(boolean role, int id) {

		String sql = "";
		if (role == true) {
			sql = "update roles set e_req=1,e_role='admin' where e_id=" + id;
			return jdbcTemplate.update(sql);
		}
		if (role == false) {
			sql = "update roles set e_req=-1,e_role='invalid' where e_id=" + id;
			return jdbcTemplate.update(sql);
		}
		return 1;
	}

	//
	public void updateRegister(User user, Login login) {
		try {
			int userId = user.getId();
			String firstName = user.getFirstName();
			String lastname = user.getLastName();
			String email = user.getEmail();
			String password = user.getPassword();

			if (user.isRole()) {

				jdbcTemplate.update("insert into register values(" + userId + ",'" + firstName + "','" + lastname
						+ "','" + email + "'," + true + ",'" + password + "')");
				jdbcTemplate.update("insert into roles values(" + userId + "," + 0 + ",'adminreq')");
				login.setType("adminreq");

			} else {

				jdbcTemplate.update("insert into register values(" + userId + ",'" + firstName + "','" + lastname
						+ "','" + email + "'," + false + ",'" + password + "')");
				jdbcTemplate.update("insert into roles values(" + userId + "," + 1 + ",'user')");
				login.setType("user");
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public List<User> readUser() throws SQLException, ClassNotFoundException {

		return jdbcTemplate.query("select * from register", new UserRowMapper());

	}

	public ArrayList<User> readAdminRequest() {

		ArrayList<User> list = jdbcTemplate.query(
				"select id,firstName from register where id in (select e_id from roles where e_req=" + 0 + ")",
				new ResultSetExtractor<ArrayList<User>>() {
					public ArrayList<User> extractData(ResultSet resultSetObj)
							throws SQLException, DataAccessException {
						ArrayList<User> List = new ArrayList<User>();
						while (resultSetObj.next()) {
							User user = new User();
							user.setId(resultSetObj.getInt(1));
							user.setFirstName(resultSetObj.getString(2));
							List.add(user);
						}
						return List;
					}
				});
		return list;

	}

	public boolean checkLogin(Login login) {
		jdbcTemplate.query("select e_role from roles where e_id=" + Integer.parseInt(login.getUserName()),
				(ResultSetExtractor<List<User>>) resultSetObj -> {
					List<User> editorList = new ArrayList<User>();
					if (resultSetObj.next()) {
						login.setType(resultSetObj.getString(1));
					}
					return editorList;
				});

		String sql = "SELECT * FROM register WHERE id=" + login.getUserName();
		User user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(User.class));
		if(user.getId()==Integer.parseInt(login.getUserName())&&user.getPassword().equals(login.getPassWord())) {
			return true;
		}
		return false;

	}

	public User getUserObject(int id) {
		// TODO Auto-generated method stub

		String sql = "SELECT * FROM register WHERE id=" + id;
		User user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(User.class));
		return user;
	}

	public void updateUser(User user) {
		// TODO Auto-generated method stub
		String SQL = "update register set firstName=?,lastName=?,email=?,password=? where id=?";
		jdbcTemplate.update(SQL, user.getFirstName(), user.getLastName(), user.getEmail(), user.getPassword(),
				user.getId());
		return;
	}

	public void addAdd(Advertisement add, MultipartFile file){
		// TODO Auto-generated method stub
try {
		String sql = "insert into advertisement values(9,12345,?,?,?,?,?)";

		 jdbcTemplate.update(sql, new Object[] { add.getTitle(),add.getCategory(),
				 add.getField1(),add.getField2(),file.getBytes()});
}
catch (Exception e) {
	// TODO: handle exception
	System.out.println(e);
}
	}
	
	public Advertisement getAddObject(int id) {
		// TODO Auto-generated method stub

		String sql = "SELECT * FROM advertisement WHERE id=" + id;
		Advertisement user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(Advertisement.class));
		return user;
	}

	public void addFeedback(String question) {
		// TODO Auto-generated method stub
		String sql = "insert into feedback(question,rating) values(?,?)";

		 jdbcTemplate.update(sql, new Object[] {question,-1 });
	}

	public List<Feedback> getAdminQuestion() {
		// TODO Auto-generated method stub

		String sql = "SELECT * FROM feedback";
		 List<Feedback> list=jdbcTemplate.query(sql,
	               BeanPropertyRowMapper.newInstance(Feedback.class));
		return list;
	}

	public void submitFeed(int rating, int id) {
		// TODO Auto-generated method stub
		String sql = "update feedback set rating=? where id=?";

		 jdbcTemplate.update(sql, new Object[] {rating,id});
	}

}
