package com.bisn.City_Classified_And_Search.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class Login {
	
	
	
	@NotNull(message = "Id cannot be empty")
	private String userName;
	@NotEmpty(message = "password cannot be empty")
	private String passWord;
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Login() {
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	@Override
	public String toString() {
		return "Login [userName=" + userName + ", passWord=" + passWord + ", type=" + type + "]";

	}
}
