package com.bisn.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.bisn.City_Classified_And_Search.model.Advertisement;
import com.bisn.City_Classified_And_Search.model.Feedback;
import com.bisn.City_Classified_And_Search.model.Login;
import com.bisn.City_Classified_And_Search.model.User;
import com.bisn.City_Classified_And_Search.service.UserService;

@SessionAttributes("id")
@Controller
public class DashBoardController {

	@Autowired
	UserService service;

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String showLoginPage(@ModelAttribute("add") Advertisement add) {
		return "addAdDash";
	}

	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public String showLogin(@ModelAttribute("add") Advertisement add,@ModelAttribute @Valid Login login, BindingResult result, Model model,
			HttpSession session) {
		if (result.hasErrors()) {
			return "login";
		}
		if (login.getUserName().equals("1") && login.getPassWord().equals("root")) {
			return "redirect:/superuser";
		}
		boolean checkLogin = service.checkLogin(login);
		// model.addAttribute("login",login);
		model.addAttribute("id", login.getUserName());
		session.setAttribute("login", login);
		if (login.getType().equals("adminreq")) {
			return "redirect:/login";
		}
		if (login.getPassWord().isEmpty() || login.getUserName().isEmpty() || checkLogin == false) {
			return "login";
		}
		User userObject = service.getUserObject(Integer.parseInt(login.getUserName()));
		session.setAttribute("userobj", userObject);
		return "addAdDash";
	}

	@GetMapping("/updateUserDash")
	public String showUpdateUserDashPage(@ModelAttribute User user, Model model) {
//		int id = Integer.parseInt((String) model.getAttribute("id"));
//		System.out.println(id);
//		User userObject = service.getUserObject(id);
//		System.out.println(user.toString());
//		model.addAttribute("userobj", userObject);

		return "updateUserDash";
	}

	@PostMapping("/updatedUserDash")
	public String showUpdatedUserDashPage(@ModelAttribute User user, Model model, HttpSession session) {

		service.updateUser(user);
		User userObject = service.getUserObject(user.getId());
		session.setAttribute("userobj", userObject);
		// userObject=user;
		return "updateUserDash";
	}

	@GetMapping("/viewAdDash")
	public String showViewAdDashPage(Model model) {
		Advertisement addObject = service.getAddObject(6);
		model.addAttribute("add", addObject);
		return "viewAdDash";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		System.out.println("Session closed;" + session.getAttribute("login").toString());
		session.invalidate();
		return "redirect:/login";
	}
	
	@PostMapping("/addAdd")
	public String getAdd(@ModelAttribute("add") Advertisement add,
			@RequestParam("img") MultipartFile file,BindingResult result, ModelMap modelMap) throws IOException {
		System.out.println(add.toString());
		add.setFile(file);
		service.addAdd(add,file);
		return "addAdDash";
	}
	
	@GetMapping("/feedback")
	public String getFeedBackPage(HttpSession session,Model model) {
		Login login = (Login) session.getAttribute("login");
		if(login.getType().equals("user"))
		{
			List<Feedback> adminQuestion = service.getAdminQuestion();
			System.out.println(adminQuestion.toString());
			model.addAttribute("feedback", adminQuestion);
			return "userFeedback";
		}
		else {
		return "adminFeedback";
		}
	}
	
	@PostMapping("/addFeedback")
	public String addfeedback(@RequestParam("question")String question) {
		
//		System.out.println(question);
		service.addFeedback(question);
		return "adminFeedback";
	}
	
	@PostMapping("/submitFeedback")
	public String submitFeedback(HttpServletRequest request) {
		List<String> params = Collections.list(request.getParameterNames());
		int i=1;//Get param name
		for (String p: params)
		{
		  System.out.println( request.getParameter(p));// get param value for each param
		  service.submitFeed(Integer.parseInt(request.getParameter(p)),i);
		  i++;
		}
		
		return "userFeedback";
	}

}
