create database db;
use db;
create table roles(eid int , name varchar(20),type boolean,request varchar(20));
create table register(
id int auto_increment primary key,
 firstName varchar(20),
 lastName varchar(20),
 email varchar(20),
 role boolean,
 password varchar(20)
);
create table roles(e_id int primary key ,e_req int,e_role varchar(20));
create table advertisement(
id int primary key,
e_id int,
title varchar(30),
category varchar(30),
field1 varchar(30),
field2 varchar(30),
image mediumblob
);

create table feedback(id int auto_increment primary key,question varchar(50),rating int );
select * from feedback;
truncate table advertisement;
insert into advertisement values(3,12345,"a","movie","a","b",LOAD_FILE('C:\Users\Barath\Desktop\3d.png'));
select * from advertisement;
SHOW WARNINGS;
select * from roles;
drop table role;
select * from register;
update register set role=true where id=1;
truncate table register;
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';
SET SQL_SAFE_UPDATES = 0;